# Process the data files from GEO submission:
# GSE9911
# reproduce figures from Yeast paper

library(limma)

targets <- readTargets("targets.csv")

targets

RG <- read.maimages(targets$FileName, source="agilent")

types <- readSpotTypes("spottype.txt")
status <- controlStatus(types, RG)
RG$genes$Status <- status

# Override background subtraction
RG.r <- backgroundCorrect(RG, method="none")

plotMA(RG)
plotMA(RG, array=2)

RG.subset <- RG.r[RG.r$genes$Status == "gene",]
RG.sort <- RG.subset[order(RG.subset$genes$GeneName),]

#plotMA3by2(RG.subset, "subset-RG.r")
MA.r <- normalizeWithinArrays(RG.sort,method="loess")

#plotMA3by2(MA.r,prefix="subset-MAr")

# Check if we need between array normalization
boxplot(MA.r$M~col(MA.r$M),names=colnames(MA.r$M))
plotDensities(MA.r)

MA.b <- normalizeBetweenArrays(MA.r,method="Aquantile")
#plotMA3by2(MA.b, prefix="subset-MAb")

plotMA(MA.b)

boxplot(MA.b$M~col(MA.b$M),names=colnames(MA.b$M))
plotDensities(MA.b)

design <- modelMatrix(targets, ref="C")

# handle duplicated genes the easy way
corfit <- duplicateCorrelation(MA.b, ndups=2, design)


fit <- lmFit(MA.b,design,correlation=corfit$consensus)

fit.b <- eBayes(fit)

# build a contrast matrix in order
contrast.matrix <- makeContrasts(m30,h3,h6, levels=design)

fit2 <- contrasts.fit(fit,contrast.matrix)
fit2.b <- eBayes(fit2)

#results <- classifyTestsF(fit2.b)
#vennCounts(results)
#vennDiagram(results)

calls2.fdr <- decideTests(fit2.b, adjust.method="fdr")

# write.fit(fit2.b,results=calls2.fdr,adjust="fdr",file="yeast-fit.txt",digits=3)


vennDiagram(calls2.fdr)

volcanoplot(fit2.b,coef=1,highlight=0,names=fit2.b$genes$GeneName,main="m30")
abline(h=0)

volcanoplot(fit2.b,coef=2,highlight=0,names=fit2.b$genes$GeneName, main="h3")
abline(h=0)

volcanoplot(fit2.b,coef=3,highlight=0,names=fit2.b$genes$GeneName, main="h6")
abline(h=0)
